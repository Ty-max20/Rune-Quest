import React, { useEffect, useRef, useState } from 'react';
import { TILE, MAP_W, MAP_H, defaultIsBlocked } from './world';
import { astar } from './pathfinder';

const WS_URL = (import.meta.env.VITE_WS_URL) || 'ws://localhost:8080';
export default function App(){
  const canvasRef = useRef();
  const [ws, setWs] = useState(null);
  const [playerId, setPlayerId] = useState(null);
  const [pos, setPos] = useState({x:4,y:4});
  const [players, setPlayers] = useState({});
  const [hp, setHp] = useState(100);
  const [inCombat, setInCombat] = useState(false);
  useEffect(()=>{
    const s = new WebSocket(WS_URL);
    s.addEventListener('open', ()=>console.log('ws open'));
    s.addEventListener('message', (ev)=>{
      const data = JSON.parse(ev.data);
      if (data.type === 'welcome') setPlayerId(data.id);
      if (data.type === 'move') setPlayers(p=>({...p, [data.id]: {...(p[data.id]||{}), x:data.x, y:data.y}}));
      if (data.type === 'attack') {
        if (data.targetId === playerId) setHp(h => Math.max(0, h - (data.damage||1)));
      }
    });
    setWs(s);
    return ()=> s.close();
  },[]);

  useEffect(()=>{
    let raf;
    const step = ()=>{
      const canvas = canvasRef.current;
      if (canvas){
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0,0,canvas.width, canvas.height);
        for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++){
          const c = ((x+y)%2===0)?'#264d26':'#2b5b2b';
          ctx.fillStyle = defaultIsBlocked(x,y)?'#4b3728':c;
          ctx.fillRect(x*TILE,y*TILE,TILE,TILE);
        }
        const cx = pos.x * TILE + TILE/2;
        const cy = pos.y * TILE + TILE/2;
        ctx.fillStyle = '#6b4b2b'; ctx.fillRect(cx-12, cy-8, 24, 28);
        ctx.beginPath(); ctx.arc(cx, cy-14, 10, 0, Math.PI*2); ctx.fillStyle='#f2d9b3'; ctx.fill();
        if (inCombat){ const w=48; ctx.fillStyle='#000'; ctx.fillRect(cx - w/2, cy-40, w, 8); ctx.fillStyle='#aa2222'; ctx.fillRect(cx - w/2 +2, cy-38, (w-4)*(hp/100),4); }
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return ()=> cancelAnimationFrame(raf);
  },[pos, inCombat, hp]);

  function onCanvasClick(e){
    const rect = canvasRef.current.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left)/TILE);
    const y = Math.floor((e.clientY - rect.top)/TILE);
    if (defaultIsBlocked(x,y)) return;
    const path = astar(pos, {x,y}, defaultIsBlocked, MAP_W, MAP_H);
    if (path) {
      followPath(path.slice(1));
    }
  }
  async function followPath(path){
    for (const step of path){
      await new Promise(res => setTimeout(res, 200));
      setPos(step);
      if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'move', x: step.x, y: step.y }));
    }
  }
  function save(){
    if (!playerId) return;
    fetch((import.meta.env.VITE_HTTP_URL || 'http://localhost:8080') + '/save-player', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id: playerId, data: { pos, hp, gold:0 } })
    }).then(()=>alert('Saved'));
  }
  return (<div><div className="hud">Player: {playerId||'---'} HP: {hp} <button onClick={()=>setInCombat(c=>!c)}>Toggle Combat</button> <button onClick={save}>Save</button></div><canvas ref={canvasRef} width={MAP_W*TILE} height={MAP_H*TILE} onClick={onCanvasClick} style={{border:'2px solid #222'}} /></div>);
}
