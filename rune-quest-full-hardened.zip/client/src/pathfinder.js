export function astar(start, goal, isBlocked, w, h) {
  const key = (n) => `${n.x},${n.y}`;
  const inBounds = (x,y)=> x>=0 && y>=0 && x<w && y<h;
  const neighbors = (n) => {
    const deltas = [[1,0],[-1,0],[0,1],[0,-1]];
    return deltas.map(([dx,dy])=>({x:n.x+dx,y:n.y+dy})).filter(p=>inBounds(p.x,p.y) && !isBlocked(p.x,p.y));
  }
  const open = new Map();
  const closed = new Set();
  function hScore(a,b){ return Math.abs(a.x-b.x)+Math.abs(a.y-b.y); }
  const startNode = { x:start.x, y:start.y, g:0, f:hScore(start, goal), parent: null };
  open.set(key(startNode), startNode);
  while(open.size){
    let curr; let currKey;
    for (const [k,n] of open.entries()) {
      if (!curr || n.f < curr.f) { curr = n; currKey = k; }
    }
    if (curr.x === goal.x && curr.y === goal.y) {
      const path = [];
      let it = curr;
      while (it){ path.push({x:it.x,y:it.y}); it=it.parent; }
      return path.reverse();
    }
    open.delete(currKey);
    closed.add(currKey);
    for (const nb of neighbors(curr)){
      const nbKey = key(nb);
      if (closed.has(nbKey)) continue;
      const g = curr.g + 1;
      const existing = open.get(nbKey);
      if (!existing || g < existing.g) {
        const node = { x: nb.x, y: nb.y, g, f: g + hScore(nb, goal), parent: curr };
        open.set(nbKey, node);
      }
    }
  }
  return null;
}
