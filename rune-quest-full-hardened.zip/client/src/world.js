export const TILE = 48;
export const MAP_W = 24;
export const MAP_H = 14;
export function defaultIsBlocked(x,y){ if (x<0||y<0||x>=MAP_W||y>=MAP_H) return true; if (x===12 && y>=3 && y<=10) return true; return false; }
