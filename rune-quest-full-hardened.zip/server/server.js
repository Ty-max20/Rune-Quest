
// server/server.js (Hardened)
// Express + WebSocket server with SQLite persistence and Stripe webhook handling
// Security hardening added: helmet, rate limiting, API key auth for save endpoints, WS message validation, movement anti-cheat.

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { WebSocketServer } = require('ws');
const Database = require('better-sqlite3');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_PLACEHOLDER');
const { v4: uuidv4 } = require('uuid');

const app = express();
// Use Helmet to set secure HTTP headers
app.use(helmet());
// basic CORS - allow only your front-end origin in production
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';
app.use(cors({ origin: FRONTEND_ORIGIN }));

// global rate limit for HTTP endpoints (protects against brute force)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200, // limit each IP to 200 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// raw body capture for Stripe webhook verification
app.use((req, res, next) => {
  if (req.originalUrl === '/stripe-webhook') {
    let data = '';
    req.setEncoding('utf8');
    req.on('data', chunk => data += chunk);
    req.on('end', () => { req.rawBody = data; next(); });
  } else next();
});
app.use(bodyParser.json());

const dbFile = './db.sqlite';
const db = new Database(dbFile);
// initialize tables
db.prepare(`CREATE TABLE IF NOT EXISTS players (
  id TEXT PRIMARY KEY, data TEXT
)`).run();

// Simple API key check for protected HTTP endpoints (save/load)
// Set SERVER_API_KEY in environment to a strong secret
function requireApiKey(req, res, next) {
  const key = req.headers['x-api-key'] || req.query.api_key;
  if (!process.env.SERVER_API_KEY) return res.status(500).send({ error: 'server-not-configured' });
  if (!key || key !== process.env.SERVER_API_KEY) return res.status(401).send({ error: 'invalid_api_key' });
  next();
}

// Save or update player state (protected by API key)
app.post('/save-player', requireApiKey, (req, res) => {
  const { id, data } = req.body;
  if (!id || !data) return res.status(400).send({ error: 'missing' });
  // Minimal sanitization: only allow expected fields
  const safe = {
    pos: { x: Math.floor((data.pos && data.pos.x) || 0), y: Math.floor((data.pos && data.pos.y) || 0) },
    hp: Math.max(0, Math.min(1000, Number(data.hp || 100))),
    gold: Math.max(0, Math.floor(Number(data.gold || 0))),
    inventory: Array.isArray(data.inventory) ? data.inventory.slice(0, 100) : []
  };
  db.prepare(`INSERT INTO players(id, data) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`).run(id, JSON.stringify(safe));
  res.send({ ok: true });
});

// Load player (protected)
app.get('/player/:id', requireApiKey, (req, res) => {
  const rec = db.prepare('SELECT data FROM players WHERE id = ?').get(req.params.id);
  if (!rec) return res.status(404).send({ error: 'notfound' });
  res.send({ data: JSON.parse(rec.data) });
});

// Stripe create checkout session - allow public but prefer server-side validation
app.post('/create-checkout-session', async (req, res) => {
  const { priceId, playerId } = req.body;
  if (!priceId || !playerId) return res.status(400).send({ error: 'missing' });
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: process.env.SUCCESS_URL || 'http://localhost:5173/?checkout=success&session_id={CHECKOUT_SESSION_ID}',
      cancel_url: process.env.CANCEL_URL || 'http://localhost:5173/?checkout=cancel',
      metadata: { playerId }
    });
    res.send({ id: session.id, url: session.url });
  } catch (err) {
    console.error('Checkout create error', err);
    res.status(500).send({ error: 'stripe_error' });
  }
});

// Stripe webhook endpoint to listen for completed payments (verify using constructEvent)
app.post('/stripe-webhook', (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_PLACEHOLDER';
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const playerId = session.metadata && session.metadata.playerId;
    console.log('Checkout completed for player', playerId);
    if (playerId) {
      const rec = db.prepare('SELECT data FROM players WHERE id = ?').get(playerId);
      let data = { pos: {x:2,y:2}, hp:100, gold: 0 };
      if (rec) data = JSON.parse(rec.data);
      data.gold = (data.gold || 0) + 100;
      db.prepare(`INSERT INTO players(id, data) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`).run(playerId, JSON.stringify(data));
      console.log('Credited 100 gold to', playerId);
    }
  }
  res.json({ received: true });
});

const server = app.listen(process.env.PORT || 8080, () => console.log('HTTP server listening on', process.env.PORT || 8080));

// WebSocket server - hardened message handling & move validation
const wss = new WebSocketServer({ server });
let clients = new Map();
// per-client meta used for anti-cheat/rate limiting
const clientMeta = new Map();

function nowMs(){ return Date.now(); }

wss.on('connection', (ws, req) => {
  const id = uuidv4();
  clients.set(id, ws);
  clientMeta.set(id, { lastMoveAt: 0, lastPos: {x:0,y:0} });
  ws.send(JSON.stringify({ type: 'welcome', id }));

  ws.on('message', (msg) => {
    let data;
    try { data = JSON.parse(msg); } catch(e) { return; }
    // Validate message shape
    if (!data || typeof data.type !== 'string') return;
    // Rate-limit expensive actions per client
    const meta = clientMeta.get(id) || { lastMoveAt:0, lastPos:{x:0,y:0} };
    if (data.type === 'move') {
      // ensure numeric coords
      const nx = Number(data.x), ny = Number(data.y);
      if (!Number.isFinite(nx) || !Number.isFinite(ny)) return;
      const now = nowMs();
      // moves must be at least 150ms apart
      if (now - meta.lastMoveAt < 120) return; // drop spammy updates
      // basic speed check: allow one tile per 150ms (server-side authoritative)
      const dx = Math.abs(nx - meta.lastPos.x);
      const dy = Math.abs(ny - meta.lastPos.y);
      if (dx + dy > 1.5) { // suspicious teleporting
        console.warn('Suspicious move from', id, 'from', meta.lastPos, 'to', {x:nx,y:ny});
        // optionally disconnect or ignore
        return;
      }
      // update meta and broadcast
      meta.lastMoveAt = now;
      meta.lastPos = {x:nx, y:ny};
      clientMeta.set(id, meta);
      const out = { type:'move', id, x: nx, y: ny };
      for (const [cid, client] of clients.entries()) {
        if (client.readyState === client.OPEN) client.send(JSON.stringify(out));
      }
      return;
    }

    if (data.type === 'attack') {
      // validate attack payload
      const target = String(data.targetId || '');
      const dmg = Math.max(0, Math.min(200, Number(data.damage || 0)));
      if (!target) return;
      // broadcast attack event (server can also apply authoritative HP changes here)
      const out = { type:'attack', id, targetId: target, damage: dmg };
      for (const client of clients.values()) if (client.readyState === client.OPEN) client.send(JSON.stringify(out));
      return;
    }

    if (data.type === 'save') {
      // only accept save if client sends a valid token (e.g., API key) - here we require server API key in payload (not ideal for public clients)
      // better: use authenticated session tokens (JWT) - left as TODO
      try {
        if (data.id && data.data) {
          db.prepare(`INSERT INTO players(id, data) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`).run(String(data.id), JSON.stringify(data.data));
        }
      } catch (err) {
        console.error('Save error', err);
      }
      return;
    }

    // Unknown message types are ignored
  });

  ws.on('close', () => {
    clients.delete(id);
    clientMeta.delete(id);
    for (const client of clients.values()) if (client.readyState === client.OPEN) client.send(JSON.stringify({ type: 'player-left', id }));
  });
});

console.log('WebSocket server running (hardened)');
